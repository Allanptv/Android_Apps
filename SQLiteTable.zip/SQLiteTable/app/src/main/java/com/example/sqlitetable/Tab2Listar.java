package com.example.sqlitetable;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class Tab2Listar extends Fragment {
    private ListView listView;
    private Button btnRefresh;

    private ArrayAdapter<Contato> adapter;
    private List<Contato> contatos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup coontainer, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.tab2_listar, coontainer, false);

        listView = rootView.findViewById(R.id.listView);
        btnRefresh = rootView.findViewById(R.id.btn_atualizat);

        contatos = userRecover();
        adapter  = new ArrayAdapter<Contato>(getContext().getApplicationContext(), android.R.layout.simple_list_item_1, contatos);
        listView.setAdapter(adapter);

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contatos = userRecover();
                adapter  = new ArrayAdapter<Contato>(getContext().getApplicationContext(), android.R.layout.simple_list_item_1, contatos);
                listView.setAdapter(adapter);
            }
        });

        return rootView;
    }

    private List<Contato> userRecover(){
        Contato contato;

        List<Contato> contatos = new ArrayList<Contato>();

        try{
            SQLiteDatabase dataBases = getContext().getApplicationContext().openOrCreateDatabase("bancoContatos", Context.MODE_PRIVATE, null);

            Cursor cursor = dataBases.rawQuery("SELECT id, name, email, phone, address, birth FROM Contato", null);

            int indiceID = cursor.getColumnIndex("id");
            int indiceName = cursor.getColumnIndex("name");
            int indiceEmail = cursor.getColumnIndex("email");
            int indicePhone = cursor.getColumnIndex("phone");
            int indiceAddress = cursor.getColumnIndex("address");
            int indiceBirth = cursor.getColumnIndex("birth");

            cursor.moveToFirst();

            while(cursor != null){
                contato = new Contato(cursor.getString(indiceName), cursor.getString(indiceEmail), cursor.getString(indicePhone), cursor.getString(indiceAddress), cursor.getString(indiceBirth));
                contato.setId(Integer.parseInt(cursor.getString(indiceID)));
                contatos.add(contato);
                contato = null;

                cursor.moveToNext();

            }

        } catch(Exception e){
            e.printStackTrace();
        }
        return contatos;
    }

}
