package com.example.sqlitetable;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import static android.content.Context.MODE_PRIVATE;

public class Tab3Atualizar extends Fragment {
    private Button btnSearch, btnUpdate, brnDelete;
    private EditText edtTextName, edtTextEmail, edtTextPhone, edtTextAddress, edtTextBirth, edtTextUserId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.tab3_atualizar, container, false);

        btnSearch = rootView.findViewById(R.id.btn_search);
        btnUpdate = rootView.findViewById(R.id.btn_update);
        brnDelete = rootView.findViewById(R.id.btn_delete);

        edtTextName = rootView.findViewById(R.id.editText_name);
        edtTextEmail = rootView.findViewById(R.id.editText_email);
        edtTextPhone = rootView.findViewById(R.id.editText_phone);
        edtTextAddress = rootView.findViewById(R.id.editText_address);
        edtTextBirth = rootView.findViewById(R.id.editText_birth);
        edtTextUserId = rootView.findViewById(R.id.editText_idUser);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(edtTextUserId.getText().toString());

                Contato contato = userRecover(id);

                if(contato !=null){
                    edtTextName.setText(contato.getName());
                    edtTextEmail.setText(contato.getEmail());
                    edtTextPhone.setText(contato.getPhone());
                    edtTextAddress.setText(contato.getAddress());
                    edtTextBirth.setText(contato.getBirth());
                }else{
                    Toast.makeText(getContext().getApplicationContext(), "Usuário não encontrado.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edtTextName.getText().toString();
                String email = edtTextEmail.getText().toString();
                String phone = edtTextPhone.getText().toString();
                String address = edtTextAddress.getText().toString();
                String birth = edtTextBirth.getText().toString();

                int id = Integer.parseInt(edtTextUserId.getText().toString());

                Contato contato = new Contato(name, email, phone, address, birth);

                contato.setId(id);

                userUpdate(contato);

                Toast.makeText(getContext().getApplicationContext(), "Atualizado com sucesso", Toast.LENGTH_SHORT).show();

                edtTextName.setText("");
                edtTextEmail.setText("");
                edtTextPhone.setText("");
                edtTextAddress.setText("");
                edtTextBirth.setText("");
            }
        });

        brnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(edtTextUserId.getText().toString());

                usersDelete(id);

                Toast.makeText(getContext().getApplicationContext(), "Excluído com sucesso", Toast.LENGTH_SHORT).show();

                edtTextName.setText("");
                edtTextEmail.setText("");
                edtTextPhone.setText("");
                edtTextAddress.setText("");
                edtTextBirth.setText("");
            }
        });
        return rootView;
    }

    private Contato userRecover(int id){
        Contato contato = null;

        try{
            SQLiteDatabase dataBases = getContext().getApplicationContext().openOrCreateDatabase("bancoContatos", MODE_PRIVATE, null);

            Cursor cursor = dataBases.rawQuery("SELECT id, name, email, phone, address, birth FROM Contato WHERE id = " + String.valueOf(id), null);

            int indiceID = cursor.getColumnIndex("id");
            int indiceName = cursor.getColumnIndex("name");
            int indiceEmail = cursor.getColumnIndex("email");
            int indicePhone = cursor.getColumnIndex("phone");
            int indiceAddress = cursor.getColumnIndex("address");
            int indiceBirth = cursor.getColumnIndex("birth");

            cursor.moveToFirst();

            while(cursor != null){
                contato = new Contato(cursor.getString(indiceName), cursor.getString(indiceEmail), cursor.getString(indicePhone), cursor.getString(indiceAddress), cursor.getString(indiceBirth));
                contato.setId(Integer.parseInt(cursor.getString(indiceID)));

                cursor.moveToNext();

            }

        } catch(Exception e){
            e.printStackTrace();
        }
        return contato;
    }

    private void userUpdate(Contato contato){
        try{
            SQLiteDatabase dataBases = getContext().getApplicationContext().openOrCreateDatabase("bancoContatos", MODE_PRIVATE, null);
            String update = "UPDATE Contato " + "SET name = '" + contato.getName() + "', " + "email = '" + contato.getEmail() + "', " + "phone = '" + contato.getPhone() + "', " + "address = '" + contato.getAddress() + "', " + "birth = '" + contato.getBirth() + "' " + "WHERE id = " + contato.getId();

            dataBases.execSQL(update);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    private void usersDelete(int id){
        try{
            SQLiteDatabase dataBases = getContext().getApplicationContext().openOrCreateDatabase("bancoContatos", MODE_PRIVATE, null);

            String delete = "DELETE FROM Contato " + "WHERE id = " + id;

            dataBases.execSQL(delete);

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
