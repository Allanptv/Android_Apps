package com.example.sqlitetable;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import static android.content.Context.MODE_PRIVATE;
import static android.provider.Contacts.SettingsColumns.KEY;
import static java.sql.Types.INTEGER;
import static java.sql.Types.VARCHAR;
import static java.text.Collator.PRIMARY;

public class Tab1Cadastrar extends Fragment {

    private Button btnSave, btnUpdate, brnDelete;
    private EditText edtTextName, edtTextEmail, edtTextPhone, edtTextAddress, edtTextBirth, edtTextUserId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.tab1_cadastrar, container, false);

        btnSave = (Button) rootView.findViewById(R.id.btn_salvar);
        btnUpdate = (Button) rootView.findViewById(R.id.btn_update);
        brnDelete = (Button) rootView.findViewById(R.id.btn_delete);

        edtTextName = (EditText) rootView.findViewById(R.id.editText_name);
        edtTextEmail = (EditText) rootView.findViewById(R.id.editText_email);
        edtTextPhone = (EditText) rootView.findViewById(R.id.editText_phone);
        edtTextAddress = (EditText) rootView.findViewById(R.id.editText_address);
        edtTextBirth = (EditText) rootView.findViewById(R.id.editText_birth);
        edtTextUserId = (EditText) rootView.findViewById(R.id.editText_idUser);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edtTextName.getText().toString();
                String email = edtTextEmail.getText().toString();
                String phone = edtTextPhone.getText().toString();
                String address = edtTextAddress.getText().toString();
                String birth = edtTextBirth.getText().toString();

                if((name != "") && (email != "") && (phone != "") && (address != "") && (birth != "")){
                    Contato people = new Contato(name, email, phone, address, birth);
                    userSignUP(people);
                    Toast.makeText(getContext().getApplicationContext(), "Cadastrado com sucesso", Toast.LENGTH_SHORT).show();
                }
                edtTextName.setText("");
                edtTextEmail.setText("");
                edtTextPhone.setText("");
                edtTextAddress.setText("");
                edtTextBirth.setText("");
            }
        });

        return rootView;
    }

    private void userSignUP(Contato people){
        try {

            //definimos o name e o modo do banco de dados.
            SQLiteDatabase bancoDeDados = getContext().getApplicationContext().openOrCreateDatabase("bancoContatos", MODE_PRIVATE, null);
            //criar tabela no banco de dados
            bancoDeDados.execSQL(" CREATE TABLE IF NOT EXISTS Contato(id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR, email VARCHAR, phone VARCHAR, address VARCHAR, birth VARCHAR) ");
            String insert = "INSERT INTO Contato " + "(name, email, phone, address, birth) VALUES " + "('" + people.getName() + "','" + people.getEmail() + "','" + people.getPhone() + "','" + people.getAddress() + "','" + people.getBirth() + "')";
            //inserir dados na tabela
            bancoDeDados.execSQL(insert);
        } catch(Exception e) {
            e.printStackTrace();
        }

    }
}
